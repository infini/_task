
Windows
Download SDL Developer Libraries from http://www.libsdl.org and unzip them here.

OSX
Download and install OSX SDL Developer Libraries from http://www.libsdl.org